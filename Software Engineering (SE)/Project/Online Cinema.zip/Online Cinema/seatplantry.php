<?php
  session_start();
  require('db.php');
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    
  <title></title>
  <link rel="stylesheet" type="css" href="navandheader.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <script src="nav-header.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
 <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="css/MyStyle.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="icon" href="favicon.html">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="png" href="8.png">
	</head>
  <body>

    <?php
      if (isset($_SESSION['username'])) {
    ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-info">
 <a class="navbar-brand" href="index.html"><h1 style="margin-top: -2px;"> Ticket Bazaar</h1></a>
 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav">

      <li class="nav-item">
         <a class="nav-link" href="About.html">About</a>
     </li>
        <li class="nav-item">
           <a class="nav-link" href="registration.html">Book Tickets</a>
       </li>
         <li class="nav-item">
            <a class="nav-link" href="ticketinfo.html">Ticket Information</a>
        </li>
		<li class="nav-item">
            <a class="nav-link" href="contact.html">Contact Us</a>
        </li>

        <div id="tfheader" style="margin-top: 12px;margin-left: 500px;">
  		<form id="tfnewsearch" method="get" action="http://www.google.com">
  		        <input type="text" class="tftextinput" name="q" size="21" maxlength="120"><input type="submit" value="search" class="tfbutton">
  		</form>
  	<div class="tfclear"></div>
  	</div>
    </ul>
	</div>
</nav>
 <main>
      <div class="bar">
        <h2>Ticketing</h2>
        <span class="aside"><i>...get your lucky seat, instantly.</i></span>
      </div>
      <section>
        <?php

          $query = "SELECT * FROM broadcast WHERE BroadCastId = " . $_POST['broadcast'];
          $record = mysqli_query($db_conn, $query) or die("Query Error!".mysqli_error($db_conn));
          $broadcastInfo = mysqli_fetch_array($record);
          mysqli_free_result($record);
        ?>
        <p><b>Cinema</b>: Cinema <?php print chr(65 + $broadcastInfo['CinemaId'] - 1) ?></p>
        <?php
          $query = "SELECT * FROM film WHERE FilmId = " . $broadcastInfo['FilmId'];
          $record = mysqli_query($db_conn, $query) or die("Query Error!".mysqli_error($db_conn));
          $filmInfo = mysqli_fetch_array($record);
          mysqli_free_result($record);
        ?>
        <p><b>Film</b>: <?php print $filmInfo['FilmName'] ?></p>
        <p><b>Category</b>: <?php print $filmInfo['Category'] ?></p>
        <p><b>Show Time</b>: <?php print $broadcastInfo['Dates'] . " " . $broadcastInfo['Time'] . " (" . $broadcastInfo['day'] . ")" ?></p>
      </section>

      <section class="clearfix">
        <form method="post" action="buyticket.php" onsubmit="return check();">
          <?php
            $query = "SELECT * FROM cinema WHERE CinemaId = " . $broadcastInfo['CinemaId'];
            $record = mysqli_query($db_conn, $query) or die("Query Error!".mysqli_error($db_conn));
            $houseInfo = mysqli_fetch_array($record);
            mysqli_free_result($record);

            $query = "SELECT * FROM ticket WHERE BroadCastId = " . $broadcastInfo['BroadCastId'];
            $record = mysqli_query($db_conn, $query) or die("Query Error!".mysqli_error($db_conn));
            $seatsOccupied;
            $numberOfSeatsOccupied = 0;
            while ($row = mysqli_fetch_array($record)) {
              $seatsOccupied[$numberOfSeatsOccupied][0] = $row['SeatRow'];
              $seatsOccupied[$numberOfSeatsOccupied][1] = $row['SeatCol'];
              $numberOfSeatsOccupied++;
            }
            mysqli_free_result($record);
          ?>
          <?php
            while ($houseInfo['CinRow']) {
              $rowName = chr(65 + $houseInfo['CinRow'] - 1);
          ?>
              <div class="ticketing-row">

              <?php
              for ($i = 1; $i <= $houseInfo['CinCol']; $i++) {
                $isReserved = 0;

                for ($it = 0; $it < $numberOfSeatsOccupied; $it++) {
                  if ($seatsOccupied[$it][0] == $houseInfo['CinRow'] && $seatsOccupied[$it][1] == $i)
                    $isReserved = 1;
                }


                if ($isReserved) {
                  echo "<div class='ticketing-col reserved'>";
                  print "Sold " . $rowName . $i;
                }
                else {
                  echo "<div class='ticketing-col'>";
                  print "<input type='checkbox' class='checkbox' name='seat[]' value='" . $houseInfo['CinRow'] . "|" . $i . "'>";
                  print $rowName . $i;
                }
                echo "</div>";
              }
              $houseInfo['CinRow']--;
              echo "</div>"; // Ticketing-row end
            }
          ?>
          <div class="ticketing-row">
            <div class="ticketing-col screen">
              Screen
            </div>
          </div>
          <button type="submit" name="submit" id="submit" class="two-button-one">Select Seat(s)</button>
          <a href="buywelcome.php">
            <button type="button" name="cancel" class="two-button-two">Cancel</button>
          </a>
          <input type="hidden" name="broadcast" value=" <?php echo $broadcastInfo['BroadCastId'] ?> ">
        </form>
      </section>
    </main>

    <?php
      }
      else {
    ?>
    <nav>
      <div class="logo">
        <img src="8.png">
      </div>
    </nav>
    <main>
      <div class="bar">
        <h2>Oops...</h2>
        <span class="aside"><i>you don't seem to be logged in, redirecting you to login page.</i></span>
      </div>
      <i class="fas fa-exclamation-triangle full-icon"></i>
    </main>
    <?php
        header( "refresh:3;url=i1.html" );
      }
      mysqli_close($db_conn);
    ?>
    <script type="text/javascript">
      function check() {
        var flag = -1;
        var listOfCheckboxes = document.getElementsByClassName('checkbox');
        for (var i = 0; i < listOfCheckboxes.length; i++) {
          if (listOfCheckboxes[i].checked)
            flag = 1;
        }
        if (flag == -1) {
          alert("Please choose at least one seat.");
          return false;
        }
      }
    </script>
  </body>
</html>
