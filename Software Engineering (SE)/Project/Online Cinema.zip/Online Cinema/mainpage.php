<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <title></title>
  <link rel="stylesheet" type="css" href="navandheader.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <script src="nav-header.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

  <link rel="stylesheet" href="css/MyStyle.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="icon" href="favicon.html"


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta charset="utf-8">
    <title>Your Home | PreBook</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="png" href="8.png">
</head>

<body style="font-family:sans-serif">
<?php
      if (isset($_SESSION['username'])) {
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-info">
 <a class="navbar-brand" href="index.html">Ticket Bazaar</a>
 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	<ul class="navbar-nav">

      <li class="nav-item">
         <ul class="left">
		 <a class="nav-link" href="About.html">About</a></ul>
     </li>
        <li class="nav-item">
           <a class="nav-link" href="registration.html">Book Tickets</a>
       </li>
         <li class="nav-item">
            <a class="nav-link" href="ticketinfo.html">Ticket Info</a>
        </li>
         <li class="nav-item">
            <a class="nav-link" href="logout.php">Logout</a>
        </li>
         <li class="nav-item">
            <a class="nav-link" href="comment.php">Movie Review</a>
        </li>
		<li class="nav-item">
            <a class="nav-link" href="contact.html">Contact</a>
        </li>

        <div id="tfheader"  style="margin-top: 12px;margin-left: 500px;">
  		<form id="tfnewsearch" method="get" action="http://www.google.com">
  		        <input type="text" class="tftextinput" name="q" size="21" maxlength="120"><input type="submit" value="search" class="tfbutton">
  		</form>
  	<div class="tfclear"></div>
  	</div>
    </ul>
	</div>
</nav>
<header>
  <div id="MiddleCarousel" class="carousel slide UACarousel" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#MiddleCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#MiddleCarousel" data-slide-to="1"></li>
    <li data-target="#MiddleCarousel" data-slide-to="2"></li>
    <li data-target="#MiddleCarousel" data-slide-to="3"></li>
    <li data-target="#MiddleCarousel" data-slide-to="4"></li>
	<li data-target="#MiddleCarousel" data-slide-to="5"></li>
    <li data-target="#MiddleCarousel" data-slide-to="6"></li>
    <li data-target="#MiddleCarousel" data-slide-to="7"></li>
    <li data-target="#MiddleCarousel" data-slide-to="8"></li>

  </ol>
  <div id="testimonial-carousel" class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="joker.jpg" alt="First slide" height="500px" width="300px">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="frozen.jpg" alt="Second slide"height="500px" width="300px">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="m.jpg" alt="third slide"height="500px" width="300px">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="download3.jpg" alt="fourth slide"height="500px" width="300px">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="download4.jpg" alt="fifth slide"height="500px" width="300px">
    </div>
	<div class="carousel-item">
      <img class="d-block w-100" src="Ford.jpg" alt="fifth slide"height="500px" width="300px">
    </div>
	<div class="carousel-item">
      <img class="d-block w-100" src="term1.jpg" alt="sixth slide"height="500px" width="300px">
    </div>
	<div class="carousel-item">
      <img class="d-block w-100" src="t1.jpg" alt="seventh slide"height="500px" width="300px">
    </div>
	<div class="carousel-item">
      <img class="d-block w-100" src="knives1.jpg" alt="eighth slide"height="500px" width="300px">
    </div>
  </div>
  <a class="carousel-control-prev" href="#MiddleCarousel" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#MiddleCarousel" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<nav class="w3-bar w3-black">
<div class="show-time-bg">
    <div class="show-time ">
        <div class="row">
            <div class="small-12 small-centered columns ">
                <ul class="navbar-nav">

                    <li class="left">
                        <img src="http://www.nueplex.com/dha/assets/web/images/calander-icon.png" alt="" class="icon" style="    position: relative; top: -3px;">SHOW TIME  
                    </li>
                    <a class="right">
                        <select name="broadcast">
              <?php
                $query2 = "SELECT * FROM broadcast WHERE FilmId = ".$row['FilmId'];
                $record2 = mysqli_query($db_conn, $query2) or die("Query Error!".mysqli_error($db_conn));
                while ($row2 = mysqli_fetch_array($record2)) {
              ?>
              <!-- Drop down section -->
                <option value="<?php print $row2['BroadCastId'] ?>">
                  <?php print $row2['Dates'] . " " . $row2['Time'] . " (" . $row2['day'] . ") cinema " . chr(65 + $row2['CinemaId'] - 1) ?>
                </option>
              <?php
                }
                mysqli_free_result($record2);
               ?>
             </select>
                    </a>
                    <input type="hidden" name="city" id="City" value="1">
                    <input type="hidden" name="area" id="Area" value="10">
                    <a class="right">
                        <select name="movie" id="dateShowMovie">
                            <option value="All">ALL MOVIES</option>
                                                                <option value="374">FORD V FERRARI</option>
                                                                        <option value="368">FROZEN II</option>
                                                                        <option value="369">JUMANJI: THE NEXT LEVEL</option>
                                                                        <option value="365">MALEFICENT: MISTRESS OF EVIL</option>
                                                                        <option value="371">TERMINATOR: DARK FATE</option>
                                                                        <option value="367">KNIVES OUT</option>
                                                                        <option value="349">JOKER</option>
                                                                        <option value="383">21 BRIDGES</option>
                                                                        <option value="382">TALASH</option>
                                                            </select>
                    </a>
                    <a class="right">
                        <select name="cinema" id="dateShowCinema">
                            <option value="All">ALL CINEMAS</option>
                                                                <option value="3">CINEMA 1</option>
                                                                        <option value="4">CINEMA 2</option>
                                                                        <option value="5">CINEMA 3</option>
                                                                        <option value="6">CINEMA 4</option>
                                                            </select>
                    </a>
                </ul>
            </div>
        </div>
    </div>
                            </div>
</nav>
<div class="row m-0 p-0">
<div class ="col-12 m-0 p-0">

<div class="w3-container">

<div class="w3-bar w3-black">
  <div class="w3-bar-item w3-hover-grey">Cinema 1</div>
</div>

</div>
<div class="columns">
  <ul class="price">
    <li class="header">11:00 AM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>FROZEN II</strong></a></h4></li>
    <li>Digital 3D</li>
    <li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.900
	</span></li>  
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">01:30 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>MALEFICENT:MISTRESS OF EVIL</strong></a></h4></li>
    <li>Digital 3D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.800
	</span></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">04:00 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>TERMINATOR: DARK FATE</strong></a></h4></li>
    <li>Digital 2D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.800
	</span></li>
  </ul>
</div>
<div class="columns">
  <ul class="price">
    <li class="header">07:00 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>FORD V FERRARI</strong></a></h4></li>
    <li>Digital 2D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.800
	</span></li>
  </ul>
</div>
<div class="columns">
  <ul class="price">
    <li class="header">10:15 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>FORD V FERRARI</strong></a></h4></li>
    <li>Digital 2D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.800
	</span></li>
  </ul>
</div>
<div class="columns">
  <ul class="price">
    <li class="header">01:30 AM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>TERMINATOR: DARK FATE</strong></a></h4></li>
    <li>Digital 2D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.800
	</span></li>
  </ul>
</div>
<div class="w3-container">

<div class="w3-bar w3-black">
  <div class="w3-bar-item w3-hover-grey">Cinema 2</div>
</div>

</div>
<div class="columns">
  <ul class="price">
    <li class="header">01:45 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>FROZEN II</strong>
</a></h4></li>
    <li>Digital 3D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.900
	</span></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">04:30 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>FROZEN II</strong></a></h4></li>
    <li>Digital 3D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.900
	</span></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">07:15 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>FROZEN II</strong></a></h4></li>
    <li>Digital 3D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.900
	</span></li>
  </ul>
</div>
<div class="columns">
  <ul class="price">
    <li class="header">10:00 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>FROZEN II</strong></a></h4></li>
    <li>Digital 3D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.900
	</span></li>
  </ul>
</div>

<div class="w3-container">

<div class="w3-bar w3-black">
  <div class="w3-bar-item w3-hover-grey">Cinema 3</div>
</div>

</div>

<div class="columns">
  <ul class="price">
    <li class="header">02:30 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>KNIVES OUT</strong></a></h4></li>
    <li>Digital 2D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.800
	</span></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">05:15 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>FROZEN II</strong>
</a></h4></li>
    <li>Digital 3D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.900
	</span></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">06:00 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>KNIVES OUT</strong></a></h4></li>
    <li>Digital 2D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.800
	</span></li>
  </ul>
</div>
<div class="columns">
  <ul class="price">
    <li class="header">10:45 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>TERMINATOR: DARK FATE</strong></a></h4></li>
    <li>Digital 2D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.800
	</span></li>
  </ul>
</div>
<div class="w3-container">

<div class="w3-bar w3-black">
  <div class="w3-bar-item w3-hover-grey">Cinema 4</div>
</div>

</div>

<div class="columns">
  <ul class="price">
    <li class="header">11:15 AM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>JOKER</strong></a></h4></li>
    <li>Digital 2D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.800
	</span></li>	
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">02:00 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>21 BRIDGES</strong></a></h4></li>
    <li>Digital 2D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.800
	</span></li>
  </ul>
</div>

<div class="columns">
  <ul class="price">
    <li class="header">05:00 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>TALASH</strong></a></h4></li>
    <li>Digital 2D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.800
	</span></li>
  </ul>
</div>
<div class="columns">
  <ul class="price">
    <li class="header">07:45 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>21 BRIDGES</strong></a></h4></li>
    <li>Digital 2D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.800
	</span></li>
  </ul>
</div>
<div class="columns">
  <ul class="price">
    <li class="header">10:45 PM
</li>
    <li class="grey"><h4 class="eq-height"><a href="movie/Joker.html"><strong>KNIVES OUT</strong></a></h4></li>
    <li>Digital 2D</li>
	<li><span class="alert label" style="background: #000000!important; color:#fff;">
	Rs.800
	</span></li>
  </ul>
</div>
</div>
</div>
      <footer id="footer">
	  <div class="row m-0 p-0 mt-5 justify-content-center">
	  <div class="col-6">

			<a href="#" class="fa fa-facebook"></a>
			<a href="#" class="fa fa-twitter"></a>
			<a href="#" class="fa fa-youtube"></a>
			<a href="#" class="fa fa-instagram"></a>
			<a href="#" class="fa fa-pinterest"></a>
            <h3><p style="font-size: 30px;">© CopyRight 2019 Ticket Bazaar</p></h3>
	  </div>

	  </div>

        </footer>
</header>
<?php
}
      else {
?>
    <nav>
      <div class="logo">
        <img src="8.png">
      </div>
    </nav>
    <main>
      <div class="bar">
        <h2>Oops...</h2>
        <span class="aside"><i>you don't seem to be logged in, redirecting you to login page.</i></span>
      </div>
      <i class="fas fa-exclamation-triangle full-icon"></i>
    </main>
    <?php
        header( "refresh:3;url=index.html" );
      }
    ?>

</body>
</html>
