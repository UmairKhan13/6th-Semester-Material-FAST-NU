<?php
  session_start();
  require('db.php');
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <title></title>
  <link rel="stylesheet" type="css" href="navandheader.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <script src="nav-header.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

  <link rel="stylesheet" href="css/MyStyle.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="icon" href="favicon.html"


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="png" href="8.png">
	</head>
  <body>
    <?php
      if (isset($_SESSION['username'])) {
    ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-info">
 <a class="navbar-brand" href="index.html">Ticket Bazaar</a>
 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	<ul class="navbar-nav">

      <li class="nav-item">
         <ul class="left">
		 <a class="nav-link" href="About.html">About</a></ul>
     </li>
        <li class="nav-item">
            <a class="nav-link" href="contact.html">Contact</a>
        </li>
        <li class="nav-item">
           <a class="nav-link" href="registration.html">Book Tickets</a>
       </li>
         <li class="nav-item">
            <a class="nav-link" href="ticketinfo.html">Ticket Info</a>
        </li>
         <li class="nav-item">
            <a class="nav-link" href="logout.php">Logout</a>
        </li>
         <li class="nav-item">
            <a class="nav-link" href="Transport.html">Transport</a>
        </li>

        <div id="tfheader"  style="margin-top: 12px;margin-left: 500px;">
  		<form id="tfnewsearch" method="get" action="http://www.google.com">
  		        <input type="text" class="tftextinput" name="q" size="21" maxlength="120"><input type="submit" value="search" class="tfbutton">
  		</form>
  	<div class="tfclear"></div>
  	</div>
    </ul>
	</div>
</nav>

    <main>
      <div class="bar">
        <h2>Comments</h2>
        <span class="aside"><i>...what do you and other people think.</i></span>
      </div>
      <section>
        <form method="post" action="comment_submit.php" style="padding-bottom: 0;" onsubmit="return verify();">
          <h3 style="padding:0 1rem 0.3rem 0.5rem;float:left;width:10%;box-sizing: border-box;">Film Name: </h3>
          <select id="FilmId" name="FilmId" style="width:90%;">
          <?php
            $query = "SELECT * FROM film";
            $record = mysqli_query($db_conn, $query) or die("Query Error!".mysqli_error($db_conn));
            while($filmInfo = mysqli_fetch_array($record)) {
          ?>
            <option value="<?php echo $filmInfo['FilmId'] ?>"><?php echo $filmInfo['FilmName'] ?></option>
          <?php
            }
            mysqli_free_result($record);
           ?>
           <textarea name="comment" placeholder="Leave your comment here." id="textbox"></textarea>
           <button class="form-button" id="submit" name="submit">Submit Comment</button>
        </form>
        <div style="padding: 0 2rem">
          <button class="aside-button view-comment" id="view" onclick="retrive();">View Comment</button>
        </div>
      </section>
      <div id="comments" style="margin-top: 4rem;">

      </div>
    </main>

    <?php
      }
      else {
    ?>
    <nav>
      <div class="logo">
        <img src="8.png">
      </div>
    </nav>
    <main>
      <div class="bar">
        <h2>Oops...</h2>
        <span class="aside"><i>you don't seem to be logged in, redirecting you to login page.</i></span>
      </div>
      <i class="fas fa-exclamation-triangle full-icon"></i>
    </main>
    <?php
        header( "refresh:3;url=i1.html" );
      }
    ?>
    <script type="text/javascript">
    function verify() {
      if (!document.getElementById('textbox').value) {
        alert("Please enter a comment.");
        return false;
      }
    }
    function retrive() {
        var xmlhttp;
        if (window.XMLHttpRequest) {
          xmlhttp = new XMLHttpRequest();
        } else {
          xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function () {
          if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var commentshow = document.getElementById("comments");
            commentshow.innerHTML = xmlhttp.responseText;
          }
        }
        xmlhttp.open("GET", "comment_retrieve.php?FilmId=" + document.getElementById("FilmId").value, true);
        xmlhttp.send();
      }
    </script>
  </body>
</html>
