-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Server version: 5.7.26-MySQL
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";
--
-- Database: `ticketbaz`

-- Table structure for table `broadcast`

CREATE TABLE `broadcast` (
  `BroadCastId` int(100) NOT NULL,
  `Dates` date NOT NULL,
  `Time` varchar(100) NOT NULL,
  `FilmId` int(100) NOT NULL,
  `CinemaId` int(100) NOT NULL,
  `day` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table `broadcast`

INSERT INTO `broadcast` (`BroadCastId`, `Dates`, `Time`, `FilmId`, `CinemaId`, `day`) VALUES
(1, '2020-12-1', '11:00', 1, 1, 'Mon'),
(2, '2020-12-1', '13:30', 2, 1, 'Mon'),
(3, '2020-12-1', '16:00', 3, 1, 'Mon'),
(4, '2020-12-1', '19:00', 4, 1, 'Mon'),
(5, '2020-12-1', '22:15', 4, 1, 'Mon'),
(6, '2020-12-1', '01:30', 3, 1, 'Mon'),
(7, '2020-12-2', '13:45', 1, 2, 'Mon'),
(8, '2020-12-2', '16:30', 1, 2, 'Mon'),
(9, '2020-12-2', '19:15', 1, 2, 'Mon'),
(10, '2020-12-2', '22:00', 2, 2, 'Mon'),
(11, '2020-12-2', '14:30', 5, 3, 'Mon'),
(12, '2020-12-2', '17:15', 1, 3, 'Mon'),
(13, '2020-12-2', '20:00', 5, 3, 'Mon'),
(14, '2020-12-2', '22:45', 3, 3, 'Mon'),
(15, '2020-12-2', '11:15', 6, 4, 'Mon'),
(16, '2020-12-2', '14:00', 7, 4, 'Mon'),
(17, '2020-12-2', '17:00', 8, 4, 'Mon'),
(18, '2020-12-2', '19:45', 7, 4, 'Mon'),
(19, '2020-12-2', '22:15', 5, 4, 'Mon');

-- Table structure for table `comment`

CREATE TABLE `comment` (
  `commentId` int(100) NOT NULL,
  `FilmId` int(100) NOT NULL,
  `UserId` varchar(100) NOT NULL,
  `Comment` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`commentId`, `FilmId`, `UserId`, `Comment`) VALUES
(1, 1, 'faria', 'Best!'),
(2, 4, 'sarosh', 'I liked this movie.'),
(4, 1, 'mahnoor', 'Good movie.'),

-- --------------------------------------------------------

--
-- Table structure for table `film`
--

CREATE TABLE `film` (
  `FilmId` int(100) NOT NULL,
  `FilmName` varchar(100) NOT NULL,
  `Duration` varchar(100) NOT NULL,
  `Category` varchar(100) NOT NULL,
  `Language` varchar(100) NOT NULL,
  `Director` varchar(100) NOT NULL,
  `Description` varchar(10000) NOT NULL,
  `Poster` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `film`
--

INSERT INTO `film` (`FilmId`, `FilmName`, `Duration`, `Category`, `Language`, `Director`, `Description`, `Poster`) VALUES
(1, 'Frozen II', '103 mins', 'IIID', 'English', 'Chris Buck, Jennifer Lee', 'Anna, Elsa, Kristoff, Olaf and Sven leave Arendelle to travel to an ancient, autumn-bound forest of an enchanted land. They set out to find the origin of Elsas powers in order to save their kingdom.','frozen.png'),
(2, 'MALEFICENT: MISTRESS OF EVIL', '106 mins', 'IIID', 'English', 'Joachim Rønning', 'The complex relationship of Maleficent and Aurora continues to be explored as they face new threats to the magical land of the Moors.', 'maleficent.jpg'),
(3, 'TERMINATOR: DARK FATE', '110 mins', 'IID', 'English', 'Tim Miller', 'Sarah Connor has returned from far away, and she is gearing up with a team of agents who will fight against T-1000.', 'term.jpg'),
(4, 'FORD V FERRARI', '148 mins', 'IID', 'English', 'James Mangold', 'American car designer Carroll Shelby and driver Ken Miles battle corporate interference, the laws of physics and their own personal demons to build a revolutionary race car for Ford and challenge Ferrari at the 24 Hours of Le Mans in 1966.', 'ford.jpg');
(5, 'KNIVES OUT', '103 mins', 'IID', 'English', 'Rian Johnson', 'A detective investigates the death of a patriarch of an eccentric, combative family.', 'knives.jpg'),
(6, 'JOKER', '106 mins', 'IID', 'English', 'Todd Phillips', 'A gritty character study of Arthur Fleck, a man disregarded by society.', 'jokerr.jpg'),
(7, '21 BRIDGES', '110 mins', 'IID', 'English', 'Brian Kirk', 'An embattled NYPD detective is thrust into a citywide manhunt for a pair of cop killers after uncovering a massive and unexpected conspiracy.', '21.jpg'),
(8, 'TALASH', '148 mins', 'IIB', 'Urdu', 'Zeeshan Khan', 'It’s a story of friendship, love And adventure but also deals with the serious issue of malnutrition rife in parts of rural Pakistan.', 'talash.jpg');


CREATE TABLE `Cinema` (
  `CinemaId` int(100) NOT NULL,
  `CinRow` varchar(100) NOT NULL,
  `CinCol` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `house`
--

INSERT INTO `Cinema` (`CinemaId`, `CinRow`, `CinCol`) VALUES
(1, '5', '5'),
(2, '6', '5'),
(3, '4', '7'),
(4,'2','5');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `UserId` varchar(100) NOT NULL,
  `PW` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`UserId`, `PW`) VALUES
('', ''),
('faria', 'far123'),
('sarosh', 'sar123'),
('ayesha', 'Ayesha123'),
('ali', 'ali124');
-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `TicketId` int(100) NOT NULL,
  `SeatRow` int(11) NOT NULL,
  `SeatCol` int(11) NOT NULL,
  `BroadCastId` int(100) NOT NULL,
  `Valid` varchar(100) NOT NULL,
  `UserId` varchar(100) NOT NULL,
  `TicketType` varchar(100) NOT NULL,
  `TicketFee` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`TicketId`, `SeatRow`, `SeatCol`, `BroadCastId`, `Valid`, `UserId`, `TicketType`, `TicketFee`) VALUES
(3, 5, 3, 1, 'YES', 'faria', 'Adult', '900'),
(4, 4, 4, 1, 'YES', 'faria', 'Student', '850'),
(5, 1, 5, 2, 'YES', 'faria', 'Student', '750'),
(6, 5, 4, 1, 'YES', 'ayesha', 'Student', '850'),
(7, 4, 2, 1, 'YES', 'ayesha', 'Student', '850'),
(8, 4, 3, 1, 'YES', 'ayesha', 'Student', '850'),
(9, 6, 1, 4, 'YES', 'ayesha', 'Adult', '800'),
(10, 6, 5, 4, 'YES', 'ayesha', 'Adult', '800'),
(11, 4, 3, 4, 'YES', 'ayesha', 'Adult', '800'),
(12, 4, 4, 4, 'YES', 'ayesha', 'Adult', '800'),
(13, 3, 1, 4, 'YES', 'ayesha', 'Adult', '800'),
(14, 3, 2, 4, 'YES', 'ayesha', 'Adult', '800'),
(15, 3, 3, 4, 'YES', 'ayesha', 'Adult', '800'),
(16, 2, 3, 4, 'YES', 'ayesha', 'Adult', '800'),
(17, 2, 5, 4, 'YES', 'ayesha', 'Adult', '800'),
(18, 1, 1, 4, 'YES', 'ayesha', 'Adult', '800'),
(19, 1, 2, 4, 'YES', 'ayesha', 'Adult', '800'),
(20, 3, 3, 1, 'YES', 'faria', 'Adult', '900'),
(21, 2, 4, 1, 'YES', 'faria', 'Adult', '900'),
(22, 5, 1, 6, 'YES', 'sarosh', 'Adult', '800'),
(23, 4, 2, 6, 'YES', 'sarosh', 'Student', '750'),
(24, 1, 4, 1, 'YES', 'sarosh', 'Adult', '900'),
(25, 2, 3, 9, 'YES', 'ali', 'Adult', '800');
(22, 5, 1, 14, 'YES', 'sarosh', 'Adult', '800'),
(23, 4, 2, 8, 'YES', 'sarosh', 'Student', '850'),
(24, 1, 4, 5, 'YES', 'sarosh', 'Adult', '800'),
(25, 2, 3, 5, 'YES', 'ali', 'Adult', '800');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `broadcast`
--
ALTER TABLE `broadcast`
  ADD PRIMARY KEY (`BroadCastId`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`commentId`);

--
-- Indexes for table `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`FilmId`);

--
-- Indexes for table `house`
--
ALTER TABLE `Cinema`
  ADD PRIMARY KEY (`CinemaId`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`TicketId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `broadcast`
--
ALTER TABLE `broadcast`
  MODIFY `BroadCastId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `commentId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `film`
--
ALTER TABLE `film`
  MODIFY `FilmId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `house`
--
ALTER TABLE `Cinema`
  MODIFY `CinemaId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `TicketId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;COMMIT;

