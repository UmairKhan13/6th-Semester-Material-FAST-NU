
<?php
  session_start();
  require('db.php');
  $query = "SELECT * FROM film";
  $record = mysqli_query($db_conn, $query) or die("Query Error!".mysqli_error($db_conn));
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
      <meta charset="utf-8">
  <title></title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link rel="stylesheet" href="css/MyStyle.css">
<link rel="stylesheet" href="style.css">


<!-- fonts-->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
  <body>

    <?php
      if (isset($_SESSION['username'])) {
    ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-info">
 <a class="navbar-brand" href="index.html"><h1>Ticket Bazaar</h1></a>
 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav">

      <li class="nav-item">
         <a class="nav-link" href="About.html">About</a>
     </li>
        <li class="nav-item">
           <a class="nav-link" href="buywelcome.php">Book Tickets</a>
       </li>
         <li class="nav-item">
            <a class="nav-link" href="ticketinfo.html">Ticket Info</a>
        </li>
         <li class="nav-item">
            <a class="nav-link" href="contact.html">Contact Us</a>
        </li>

        <div id="tfheader">
  		<form id="tfnewsearch" method="get" action="http://www.google.com">
  		        <input type="text" class="tftextinput" name="q" size="21" maxlength="120"><input type="submit" value="search" class="tfbutton">
  		</form>
  	<div class="tfclear"></div>
  	</div>
    </ul>
	</div>
</nav>
<main>
      <div class="bar">
        <h2>Movies</h2>
        <span class="aside"><i>NOW SHOWING</i></span>
      </div>
      <?php
        while ($row = mysqli_fetch_array($record)) {
      ?>
      <section class="movie">
        <div class="movie-left">
          <img src="<?php print $row['Poster'] ?>">
        </div>
        <div class="movie-right">
          <h1><?php print $row['FilmName'] ?></h1>
          <h3><b>Description</b>: <?php print $row['Description'] ?></h3>
          <h4><b>Director</b>: <?php print $row['Director'] ?></h4>
          <h4><b>Duration</b>: <?php print $row['Duration'] ?></h4>
          <h4><b>Category</b>: <?php print $row['Category'] ?></h4>
          <h4><b>Language</b>: <?php print $row['Language'] ?></h4>
          <form style="padding:0;" method="post" action="seatplantry.php">
            <select name="broadcast">
              <?php
                $query2 = "SELECT * FROM broadcast WHERE FilmId = ".$row['FilmId'];
                $record2 = mysqli_query($db_conn, $query2) or die("Query Error!".mysqli_error($db_conn));
                while ($row2 = mysqli_fetch_array($record2)) {
              ?>
              <!-- Drop down section -->
                <option value="<?php print $row2['BroadCastId'] ?>">
                  <?php print $row2['Dates'] . " " . $row2['Time'] . " (" . $row2['day'] . ") cinema " . chr(65 + $row2['CinemaId'] - 1) ?>
                </option>
              <?php
                }
                mysqli_free_result($record2);
               ?>
             </select>
             <button type="submit" name="submit" id="submit" class="movie-button">Book Show</button>
          </form>
        </div>
      </section>
      <?php
        }
        mysqli_free_result($record);
      ?>
    </main>

    <?php
      }
      else {
    ?>
    <main>
      <div class="bar">
        <h2>Oops...</h2>
        <span class="aside"><i>you don't seem to be logged in, redirecting you to login page.</i></span>
      </div>
      <i class="fas fa-exclamation-triangle full-icon"></i>
    </main>
    <?php
        header( "refresh:3;url=i1.html" );
      }
      mysqli_close($db_conn);
    ?>
  </body>
</html>
