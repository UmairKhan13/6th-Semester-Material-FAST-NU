<?php
  session_start();
  require('db.php');
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <title></title>
  <link rel="stylesheet" type="css" href="navandheader.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <script src="nav-header.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

  <link rel="stylesheet" href="css/MyStyle.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

  <link rel="icon" href="favicon.html"


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
	<link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" type="png" href="8.png">
</head>

<body style="font-family:sans-serif">
 <nav class="navbar navbar-expand-lg navbar-dark bg-info">
 <a class="navbar-brand" href="index.html">Ticket Bazaar</a>
 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	<ul class="navbar-nav">

      <li class="nav-item">
         <ul class="left">
		 <a class="nav-link" href="About.html">About</a></ul>
     </li>
        <li class="nav-item">
           <a class="nav-link" href="buywelcome.php">Book Tickets</a>
       </li>
         <li class="nav-item">
            <a class="nav-link" href="ticketinfo.html">Ticket Info</a>
        </li>
         <li class="nav-item">
            <a class="nav-link" href="i1.html">Login</a>
        </li>
		<li class="nav-item">
            <a class="nav-link" href="contact.html">Contact Us</a>
        </li>

        <div id="tfheader"  style="margin-top: 12px;margin-left: 500px;">
  		<form id="tfnewsearch" method="get" action="http://www.google.com">
  		        <input type="text" class="tftextinput" name="q" size="21" maxlength="120"><input type="submit" value="search" class="tfbutton">
  		</form>
  	<div class="tfclear"></div>
  	</div>
    </ul>
	</div>
</nav>

    <?php
      if (isset($_SESSION['username'])) {
    ?>
    <main>
      <div class="bar">
        <h2>Order Confirmed</h2>
        <span class="aside"><i>...here's your order information.</i></span>
      </div>
      <?php

        $query = "SELECT * FROM broadcast WHERE BroadCastId = " . $_POST['broadcast'];
        $record = mysqli_query($db_conn, $query) or die("Query Error!".mysqli_error($db_conn));
        $broadcastInfo = mysqli_fetch_array($record);
        mysqli_free_result($record);

        $broadcastID = $_POST['broadcast'];
        $username = $_SESSION['username'];
        $query = "SELECT * FROM film WHERE FilmId = " . $broadcastInfo['FilmId'];
        $record = mysqli_query($db_conn, $query) or die("Query Error!".mysqli_error($db_conn));
        $filmInfo = mysqli_fetch_array($record);
        mysqli_free_result($record);
      ?>
      <?php
        $total = 0;
        for ($i = 0; $i < sizeof($_POST['seat']); $i++) {
          list($row,$col) = explode('|', $_POST['seat'][$i]);
          $rowName = chr(65 + $row - 1);
      ?>
      <section>
        <p><b>Cinema</b>: Broadway</p>
        <p><b>House</b>: House <?php print chr(65 + $broadcastInfo['CinemaId'] - 1) ?></p>
        <p><b>SeatNo</b>: <?php print $rowName . $col ?></p>
        <p><b>Film</b>: <?php print $filmInfo['FilmName'] ?></p>
        <p><b>Category</b>: <?php print $filmInfo['Category'] ?></p>
        <p><b>Show Time</b>: <?php print $broadcastInfo['Dates'] . " " . $broadcastInfo['Time'] . " (" . $broadcastInfo['day'] . ")" ?></p>
        <p><b>Ticket Fee</b>: <?php
          $total = $total + $_POST['type'][$i];
          if ($_POST['type'][$i] == 750)
            print "Rs 850(Student)";
          else
            print "Rs 900(Adult)";

        ?></p>
        <?php
          $ticketFee = $_POST['type'][$i];
          $ticketType;
          if ($ticketFee == 750)
            $ticketType = "Student";
          else
            $ticketType = "Adult";
          $query = "INSERT INTO ticket(SeatRow, SeatCol, BroadCastId, Valid, UserId, TicketType, TicketFee) VALUES ('$row', '$col', '$broadcastID', 'YES', '$username', '$ticketType', '$ticketFee')";
          mysqli_query($db_conn, $query) or die("Query Error!".mysqli_error($db_conn));
         ?>
      </section>
      <?php
        }
      ?>
      <section style="padding: 1rem 3rem;">
        <h3>Total Fee: Rs <?php print $total ?></h3>
        <p>Please present valid proof of age/status when purchasing Student or Senior tickets before entering the cinema house.</p>
        <a href="buywelcome.php">
          <button type="button" name="okay" class="form-button">Okay!</button>
        </a>
      </section>
    </main>

    <?php
      }
      else {
    ?>
    <main>
      <div class="bar">
        <h2>Oops...</h2>
        <span class="aside"><i>you don't seem to be logged in, redirecting you to login page.</i></span>
      </div>
      <i class="fas fa-exclamation-triangle full-icon"></i>
    </main>
    <?php
        header( "refresh:3;url=i1.html" );
      }
      mysqli_close($db_conn);
    ?>
  </body>
</html>
